import PushBullet from "pushbullet";
import Auth from "./Auth.js";
import MetaTrak from "./MetaTrak.js";

exports.handler = async (event) => {
    const pusher = new PushBullet(process.env.PB_API_KEY);

    MetaTrak.login(process.env.LOGIN, process.env.PASSWORD)
        .then(session => {
            MetaTrak.events(session, 1660389070, process.env.IMEI)
                .then(events => {
                    events.forEach(event => {
                        const desc = `MetaTrak: "${event.name}" at: "${event.time}"`;

                        pusher.note({}, event.name, desc);
                    });

                    MetaTrak.logout(session);
                })
        });
};
